#include "grammar.h"
#include <iostream.h>

int main(int argc, char *argv[]) { 
  Grammar gram("grammar.txt");

  cout << "top line:" << endl;
}
