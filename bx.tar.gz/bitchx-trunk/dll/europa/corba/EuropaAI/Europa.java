/*
 * File: ./EuropaAI/Europa.java
 * From: europa.idl
 * Date: Thu Dec 23 02:08:42 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package EuropaAI;
public interface Europa
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    void inputChat(String text)
;
}
