/*
 * hebrew.h
 * by crisk
 * 
 * for hebrew_process in hebrew.c
 * 
 */

extern unsigned char *hebrew_process(unsigned char *str);


