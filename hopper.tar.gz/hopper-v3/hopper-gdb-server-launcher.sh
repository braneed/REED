#!/bin/sh
LD_LIBRARY_PATH=/opt/hopper-v3 /opt/hopper-v3/HopperGDBServer $@
